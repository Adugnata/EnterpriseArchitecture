package edu.miu.lab6partc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab6PartCApplicationTests {

    @Test
    void contextLoads() {
    }

}
